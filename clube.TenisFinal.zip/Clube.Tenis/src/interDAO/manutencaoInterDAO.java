package interDAO;

import java.util.Date;

/**
 *
 * @author cintia - déborah - isabela
 */
public class manutencaoInterDAO {
    
    //atributos
    protected String dia;
    protected String numeroQuadra;
    protected String agendarPara;
    protected String horario;

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getNumeroQuadra() {
        return numeroQuadra;
    }

    public void setNumeroQuadra(String numeroQuadra) {
        this.numeroQuadra = numeroQuadra;
    }

    public String getAgendarPara() {
        return agendarPara;
    }

    public void setAgendarPara(String agendarPara) {
        this.agendarPara = agendarPara;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }
    

   

    public int getIdManutencao() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setIdManutencao(int idManutencao) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
