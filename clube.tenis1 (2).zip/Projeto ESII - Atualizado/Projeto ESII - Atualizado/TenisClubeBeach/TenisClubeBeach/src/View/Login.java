package View;

import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import ConexaoDao.ModuloConexao;
import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.sql.*;

/**
 *
 * @author cintia - debora - isabela
 */
public class Login extends javax.swing.JFrame {

    Connection conexao = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    public void logar (){
        String sql ="select *from tbusuario where login = ? and senha = ?";
        try {
        // as linhas abaixo preparam as consultas ao banco em funcao
        // do que foi digitado nas caixas de texto. Os ? são substituidos pelo
        //conteúdo das variáveis
         pst = conexao.prepareStatement(sql);
         pst.setString(1, txtUsu.getText());
         String captura = new String(txtSenhaa.getPassword());
         pst.setString(2,captura);
        // a linha abaixo executa a Query
         rs = pst.executeQuery();
        
           if (rs.next()){
        //a linha abaixo obtem o conteudo do campo perfil da tabela tbcliente
         String perfil= rs.getString(15);
         
        /* testando para ver se o sistema identifica qual usuário está logando
           se é o cliente product owner
           ou funcionário do clube
           System.out.println(perfil);*/
        
        //a estrutura abaixo faz o tratamento do perfil do usuário
        // se existir usuario e senha correspondente
   	//abaixo vai abrir o menu principal se a senha estiver certa
        if (perfil.equals("HU 1 a 6 - gestor de quadras")){
            MenuPrincipal principal = new MenuPrincipal ();
            principal.setVisible(true);
            MenuPrincipal.menuRel.setEnabled(true);
            MenuPrincipal.menuUsu.setEnabled(true);
            MenuPrincipal.lblUsuario.setText(rs.getString(15));
            MenuPrincipal.lblUsuario.setForeground(Color.DARK_GRAY);
            this.dispose();
            conexao.close();            
        }
            if (perfil.equals("HU 7 a 12 - gestor de usuários")){
                MenuPrincipal principal = new MenuPrincipal ();
                principal.setVisible(true);
                MenuPrincipal.menuRel.setEnabled(true);
                MenuPrincipal.menuUsu.setEnabled(true);
                MenuPrincipal.lblUsuario.setText(rs.getString(15));
                MenuPrincipal.lblUsuario.setForeground(Color.BLUE);
                this.dispose();
                conexao.close();
            }
                 if (perfil.equals("HU 13 a 15 - relatórios")){
                     MenuPrincipal principal = new MenuPrincipal ();
                     principal.setVisible(true);
                     MenuPrincipal.menuRel.setEnabled(true);
                     MenuPrincipal.menuUsu.setEnabled(true);
                     MenuPrincipal.lblUsuario.setText(rs.getString(15));
                     MenuPrincipal.lblUsuario.setForeground(Color.GREEN);
                     this.dispose();
                     conexao.close();
                }
                    if (perfil.equals("HU 17 a 27 - zelador")){
                       MenuPrincipal principal = new MenuPrincipal ();
                       principal.setVisible(true);
                       MenuPrincipal.menuQuadra.setEnabled(true);
                       MenuPrincipal.menuManutencao.setEnabled(true);
                       MenuPrincipal.menuRel.setEnabled(true);
                       MenuPrincipal.menuFinanceiro.setEnabled(false);
                       MenuPrincipal.lblUsuario.setText(rs.getString(15));
                       MenuPrincipal.lblUsuario.setForeground(Color.RED);
                       this.dispose();
                       conexao.close();
                    }
         
        }else{
               JOptionPane.showMessageDialog(rootPane, "Acesso Negado! Verifique suas credenciais!");
           }
                
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,e);
        }
    }
    
    public Login() {
        initComponents();
        //estabelecendo a conexÃo com o banco sempre nesse ponto
        conexao = ModuloConexao.conector();
        //a linha abaixo serve de apoio ao status da conexao
       //System.out.println(conexao);
        if (conexao != null){
            //lblStatus.setText("conectado");
           lblStatus.setIcon(new javax.swing.ImageIcon(getClass(). getResource("/View/Imagem/dbok_1.png")));
        }else{
            //lblStatus.setText("Não Conectado");
           lblStatus.setIcon(new javax.swing.ImageIcon(getClass(). getResource("/View/Imagem/dberror_1.png")));
        }

    }
  
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblLogin = new javax.swing.JLabel();
        txtSenha = new javax.swing.JLabel();
        txtUsu = new javax.swing.JTextField();
        txtUsuario = new javax.swing.JLabel();
        txtSenhaa = new javax.swing.JPasswordField();
        btnSair = new javax.swing.JButton();
        btnEntrar = new javax.swing.JButton();
        lblStatus = new javax.swing.JLabel();
        lblTransparencia = new javax.swing.JLabel();
        lblFundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Login");
        setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblLogin.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        lblLogin.setForeground(new java.awt.Color(255, 255, 255));
        lblLogin.setText("LOGIN");
        getContentPane().add(lblLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 70, -1, -1));

        txtSenha.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        txtSenha.setForeground(new java.awt.Color(255, 255, 255));
        txtSenha.setText("Senha");
        getContentPane().add(txtSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 280, -1, -1));

        txtUsu.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtUsu, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 200, 280, -1));

        txtUsuario.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        txtUsuario.setForeground(new java.awt.Color(255, 255, 255));
        txtUsuario.setText("Usuário");
        getContentPane().add(txtUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 170, -1, -1));

        txtSenhaa.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtSenhaa, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 310, 290, -1));

        btnSair.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnSair.setText("Sair");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });
        getContentPane().add(btnSair, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 410, 100, -1));

        btnEntrar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnEntrar.setText("Entrar");
        btnEntrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEntrarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEntrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 410, -1, -1));

        lblStatus.setForeground(new java.awt.Color(255, 255, 255));
        lblStatus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Imagem/dberror_1.png"))); // NOI18N
        getContentPane().add(lblStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 490, -1, -1));

        lblTransparencia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Imagem/Agenda-PainelFundo.png"))); // NOI18N
        getContentPane().add(lblTransparencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(-50, 0, 900, 610));

        lblFundo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Imagem/bola de tenis.jpg"))); // NOI18N
        getContentPane().add(lblFundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        setSize(new java.awt.Dimension(856, 619));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
       // executa comando ao clicar no botão sair da tela login
      this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnEntrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEntrarActionPerformed
        // executa o comando ao clicar no botão entrar da tela login
        // chamando o método logar
        logar();
    }//GEN-LAST:event_btnEntrarActionPerformed

    
    public static void main(String args[]) {
       try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEntrar;
    private javax.swing.JButton btnSair;
    private javax.swing.JLabel lblFundo;
    private javax.swing.JLabel lblLogin;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblTransparencia;
    private javax.swing.JLabel txtSenha;
    private javax.swing.JPasswordField txtSenhaa;
    private javax.swing.JTextField txtUsu;
    private javax.swing.JLabel txtUsuario;
    // End of variables declaration//GEN-END:variables

    public void exibeMensagem(String mensagem) {
        
        JOptionPane.showMessageDialog(null, mensagem);
    }
       
    //acessando os dados as informações da classe de fora
    // getters e setters

    public JPasswordField getTxtSenhaa() {
        return txtSenhaa;
    }

    public void setTxtSenhaa(JPasswordField txtSenhaa) {
        this.txtSenhaa = txtSenhaa;
    }

    public JTextField getTxtUsu() {
        return txtUsu;
    }

    public void setTxtUsu(JTextField txtUsu) {
        this.txtUsu = txtUsu;
    }
    
}
