package View;

import ConexaoDao.ModuloConexao;
import Modelos.Pessoa;
import Modelos.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author cintia - debora - isabela
 */
public class CadastroUsuario extends javax.swing.JFrame {
    
    // usando a variavel conexao do DAO
    Connection conexao = null;
    // criando variaveis especiais para conexão com o banco
    //Prepared Statemente e ResultSet são frameworks do pacote java.sql
    // e servem para preparar e executar as instruções SQL
    PreparedStatement pst = null;
    ResultSet rs = null;
    
    public CadastroUsuario() {
        initComponents();
        //estabelecendo a conexÃo com o banco sempre nesse ponto
        conexao = ModuloConexao.conector();
    }
    
    private void Pesquisar(){
        String sql ="select *from tbusuario where login = ? and senha = ?";
          try{            
            pst=conexao.prepareStatement(sql);
            pst.setString(1,txtLogin.getText()); // id = matricula
            rs=pst.executeQuery();
            if (rs.next()){
            txtNome.setText(rs.getString(2));
            txtCPF.setText(rs.getString(3));
            txtDataNasc.setText(rs.getString(4));
            cbGenero.setSelectedItem(rs.getString(5));
            txtTelefone.setText(rs.getString(6));
            txtEmail.setText(rs.getString(7));
            txtCEP.setText(rs.getString(8));
            txtLogradouro.setText(rs.getString(9));
            
            txtCidade.setText(rs.getString(10));
            cbEstado.setSelectedItem(rs.getString(11));
            txtDataCriacao.setText(rs.getString(12));
            txtUsuarioBloqueado.setText(rs.getString(13));
            cbTipoPermissao.setSelectedItem(rs.getString(14)); // tipoPermissao = perfil
            
            
            }else{
                
                JOptionPane.showMessageDialog(null,"Usuário não cadastrado");

            }
            
           /* //Validação dos campos obrigatorios
            if ((txtId.getText().isEmpty())||(txtNome.getText().isEmpty())||(txtDataCriacao.getText().isEmpty())||(txtCPF.getText().isEmpty())||(txtTelefone.getText().isEmpty())||(txtEmail.getText().isEmpty())||(txtUsuarioBloqueado.getText().isEmpty()||(cbTipoPermissao.getSelectedItem().toString().isEmpty())))
                {
                JOptionPane.showMessageDialog(null,"Preencha todos os campos obrigatorios!");
            } else {
            
            //a linha abaixo atualiza a tabela usuario com os dados do formulario 
                int adicionado = pst.executeUpdate();
                //a linha abaixo confirma a inserção de dados
                if(adicionado > 0){
                    JOptionPane.showMessageDialog(null,"Usuário adicionado com sucesso!");
                    txtNome.setText(null);
                    txtDataCriacao.setText(null);
                    txtCPF.setText(null);
                    txtTelefone.setText(null);
                    txtEmail.setText(null);
                    txtUsuarioBloqueado.setText(null);
                    cbTipoPermissao.setSelectedItem(null);
                    
                }
            }*/
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void Salvar() {
        String sql = "insert into tbusuario (id,nome,cpf,dataNascimento,genero,telefone,email,cep,logradouro,cidade,estado,usuBloqueado,tipoPermissao)) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try{            
            pst=conexao.prepareStatement(sql);
            pst.setString(1,txtLogin.getText());
            pst.setString(2,txtNome.getText());
            pst.setString(3,txtDataNasc.getText());
            pst.setString(4,cbGenero.getSelectedItem().toString());
            pst.setString(5,txtCEP.getText());
            pst.setString(6,txtCidade.getText());
            pst.setString(7,txtDataCriacao.getText());
            pst.setString(8,txtCPF.getText());
            pst.setString(9,txtTelefone.getText());
            pst.setString(10,txtEmail.getText());
            pst.setString(11,txtLogradouro.getText());
            pst.setString(12,cbEstado.getSelectedItem().toString());
            pst.setString(13,cbTipoPermissao.getSelectedItem().toString());
            pst.setString(14,txtUsuarioBloqueado.getText());
            
            //Validação dos campos obrigatorios
            if ((txtLogin.getText().isEmpty())||(txtNome.getText().isEmpty())||(txtDataCriacao.getText().isEmpty())||(txtCPF.getText().isEmpty())||(txtTelefone.getText().isEmpty())||(txtEmail.getText().isEmpty())||(cbTipoPermissao.getSelectedItem().toString().isEmpty()||(txtUsuarioBloqueado.getText().isEmpty())))
                {
                JOptionPane.showMessageDialog(null,"Preencha todos os campos obrigatorios!");
            } else {
            
            //a linha abaixo atualiza a tabela usuario com os dados do formulario 
                int adicionado = pst.executeUpdate();
                //a linha abaixo confirma a inserção de dados
                if(adicionado > 0){
                    JOptionPane.showMessageDialog(null,"Usuário adicionado com sucesso!");
                    txtLogin.setText(null); 
                    txtNome.setText(null);
                    txtDataCriacao.setText(null);
                    txtCPF.setText(null);
                    txtTelefone.setText(null);
                    txtEmail.setText(null);
                    cbTipoPermissao.setSelectedItem(null);
                    txtUsuarioBloqueado.setText(null);
                }
            }
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        
    }
}
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbNome = new javax.swing.JLabel();
        lbUsuarioBloqueado = new javax.swing.JLabel();
        lbCPF = new javax.swing.JLabel();
        lbEmail = new javax.swing.JLabel();
        lbDataCriacao = new javax.swing.JLabel();
        lbNumero = new javax.swing.JLabel();
        lbDataNascimento = new javax.swing.JLabel();
        lbGenero = new javax.swing.JLabel();
        lbCEP = new javax.swing.JLabel();
        lbSenha = new javax.swing.JLabel();
        lbEstado = new javax.swing.JLabel();
        lbTelefone = new javax.swing.JLabel();
        lbLogradouro = new javax.swing.JLabel();
        lbTipoPermissao = new javax.swing.JLabel();
        lbComplemento = new javax.swing.JLabel();
        txtNumero = new javax.swing.JTextField();
        lbBairro = new javax.swing.JLabel();
        txtComplemento = new javax.swing.JTextField();
        lbCidade = new javax.swing.JLabel();
        txtBairro = new javax.swing.JTextField();
        txtDataCriacao = new javax.swing.JTextField();
        txtCPF = new javax.swing.JTextField();
        txtCidade = new javax.swing.JTextField();
        txtCEP = new javax.swing.JTextField();
        txtNome = new javax.swing.JTextField();
        txtTelefone = new javax.swing.JTextField();
        txtDataNasc = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtLogin = new javax.swing.JTextField();
        cbEstado = new javax.swing.JComboBox<>();
        cbGenero = new javax.swing.JComboBox<>();
        btnPesquisar = new javax.swing.JButton();
        btnSalvar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        txtLogradouro = new javax.swing.JTextField();
        txtUsuarioBloqueado = new javax.swing.JTextField();
        lbId = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        cbTipoPermissao = new javax.swing.JComboBox<>();
        txtSenha = new javax.swing.JPasswordField();
        lbLogin = new javax.swing.JLabel();
        lFundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Cadastro Usuário");
        setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbNome.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbNome.setForeground(new java.awt.Color(255, 255, 255));
        lbNome.setText("Nome");
        getContentPane().add(lbNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 60, -1));

        lbUsuarioBloqueado.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbUsuarioBloqueado.setForeground(new java.awt.Color(255, 255, 255));
        lbUsuarioBloqueado.setText("*Usuário Bloqueado");
        getContentPane().add(lbUsuarioBloqueado, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 430, 170, -1));

        lbCPF.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbCPF.setForeground(new java.awt.Color(255, 255, 255));
        lbCPF.setText("CPF");
        getContentPane().add(lbCPF, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 60, -1));

        lbEmail.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbEmail.setForeground(new java.awt.Color(255, 255, 255));
        lbEmail.setText("E-mail");
        getContentPane().add(lbEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 70, -1));

        lbDataCriacao.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbDataCriacao.setForeground(new java.awt.Color(255, 255, 255));
        lbDataCriacao.setText("*Data criação");
        getContentPane().add(lbDataCriacao, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 390, 120, -1));

        lbNumero.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbNumero.setForeground(new java.awt.Color(255, 255, 255));
        lbNumero.setText("Número");
        getContentPane().add(lbNumero, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, 70, -1));

        lbDataNascimento.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbDataNascimento.setForeground(new java.awt.Color(255, 255, 255));
        lbDataNascimento.setText("Data Nasc");
        getContentPane().add(lbDataNascimento, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 90, -1));

        lbGenero.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbGenero.setForeground(new java.awt.Color(255, 255, 255));
        lbGenero.setText("Gênero");
        getContentPane().add(lbGenero, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 80, -1));

        lbCEP.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbCEP.setForeground(new java.awt.Color(255, 255, 255));
        lbCEP.setText("CEP");
        getContentPane().add(lbCEP, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 60, -1));

        lbSenha.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbSenha.setForeground(new java.awt.Color(255, 255, 255));
        lbSenha.setText("Senha");
        getContentPane().add(lbSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 350, 90, -1));

        lbEstado.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbEstado.setForeground(new java.awt.Color(255, 255, 255));
        lbEstado.setText("Estado");
        getContentPane().add(lbEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 270, 130, -1));

        lbTelefone.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbTelefone.setForeground(new java.awt.Color(255, 255, 255));
        lbTelefone.setText("Telefone");
        getContentPane().add(lbTelefone, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 80, -1));

        lbLogradouro.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbLogradouro.setForeground(new java.awt.Color(255, 255, 255));
        lbLogradouro.setText("Logradouro");
        getContentPane().add(lbLogradouro, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, 100, -1));

        lbTipoPermissao.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbTipoPermissao.setForeground(new java.awt.Color(255, 255, 255));
        lbTipoPermissao.setText("*Tipo de Permissão");
        getContentPane().add(lbTipoPermissao, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 470, 170, -1));

        lbComplemento.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbComplemento.setForeground(new java.awt.Color(255, 255, 255));
        lbComplemento.setText("Complemento");
        getContentPane().add(lbComplemento, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 440, 120, -1));

        txtNumero.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtNumero, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 390, 260, -1));

        lbBairro.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbBairro.setForeground(new java.awt.Color(255, 255, 255));
        lbBairro.setText("Bairro");
        getContentPane().add(lbBairro, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 480, 70, -1));

        txtComplemento.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtComplemento, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 430, 260, -1));

        lbCidade.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbCidade.setForeground(new java.awt.Color(255, 255, 255));
        lbCidade.setText("Cidade");
        getContentPane().add(lbCidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 230, 70, -1));

        txtBairro.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtBairro, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 470, 260, -1));

        txtDataCriacao.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtDataCriacao, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 380, 210, -1));

        txtCPF.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtCPF, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 110, 260, -1));

        txtCidade.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtCidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 220, 210, -1));

        txtCEP.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtCEP, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 310, 260, -1));

        txtNome.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 70, 260, -1));

        txtTelefone.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtTelefone, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 230, 260, -1));

        txtDataNasc.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtDataNasc, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 150, 260, -1));

        txtEmail.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 270, 260, -1));

        txtLogin.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 300, 210, -1));

        cbEstado.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cbEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RR", "RO", "RJ", "RN", "RS", "SC", "SP", "SE", "TO", " ", " " }));
        getContentPane().add(cbEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 260, 210, -1));

        cbGenero.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cbGenero.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "Feminino", "Masculino", "Homem Trans", "Mulher Trans", "Não-Binário" }));
        getContentPane().add(cbGenero, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 190, 260, -1));

        btnPesquisar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnPesquisar.setText("Pesquisar");
        btnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarActionPerformed(evt);
            }
        });
        getContentPane().add(btnPesquisar, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 600, -1, -1));

        btnSalvar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnSalvar.setText("Salvar");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalvar, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 600, -1, -1));

        btnExcluir.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnExcluir.setText("Excluir");
        getContentPane().add(btnExcluir, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 600, 120, -1));

        btnEditar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnEditar.setText("Editar");
        getContentPane().add(btnEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 600, -1, -1));

        btnSair.setText("Sair");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });
        getContentPane().add(btnSair, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 10, -1, -1));

        txtLogradouro.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtLogradouro, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 350, 260, -1));

        txtUsuarioBloqueado.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtUsuarioBloqueado, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 420, 210, -1));

        lbId.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbId.setForeground(new java.awt.Color(255, 255, 255));
        lbId.setText("Id");
        getContentPane().add(lbId, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 90, -1));

        txtId.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 260, -1));

        cbTipoPermissao.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cbTipoPermissao.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "HU 1 a 6 – gestor de quadras", "HU 7 a 12 – gestor de usuários", "HU 13 a 15 – relatórios", "HU 17 a 27 – zelador\"" }));
        getContentPane().add(cbTipoPermissao, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 460, 210, -1));

        txtSenha.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 340, 210, -1));

        lbLogin.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lbLogin.setForeground(new java.awt.Color(255, 255, 255));
        lbLogin.setText("Login");
        getContentPane().add(lbLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 310, 90, -1));

        lFundo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Imagem/bola de tenis_1.jpg"))); // NOI18N
        getContentPane().add(lFundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 940, 680));

        setSize(new java.awt.Dimension(841, 685));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        // fecha a tela
        System.exit(0);
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        // comando para salvar dados
       Salvar();
    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarActionPerformed
        // comando para pesquisar dados
        Pesquisar();
    }//GEN-LAST:event_btnPesquisarActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CadastroUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CadastroUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CadastroUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CadastroUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnPesquisar;
    private javax.swing.JButton btnSair;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JComboBox<String> cbEstado;
    private javax.swing.JComboBox<String> cbGenero;
    private javax.swing.JComboBox<String> cbTipoPermissao;
    private javax.swing.JLabel lFundo;
    private javax.swing.JLabel lbBairro;
    private javax.swing.JLabel lbCEP;
    private javax.swing.JLabel lbCPF;
    private javax.swing.JLabel lbCidade;
    private javax.swing.JLabel lbComplemento;
    private javax.swing.JLabel lbDataCriacao;
    private javax.swing.JLabel lbDataNascimento;
    private javax.swing.JLabel lbEmail;
    private javax.swing.JLabel lbEstado;
    private javax.swing.JLabel lbGenero;
    private javax.swing.JLabel lbId;
    private javax.swing.JLabel lbLogin;
    private javax.swing.JLabel lbLogradouro;
    private javax.swing.JLabel lbNome;
    private javax.swing.JLabel lbNumero;
    private javax.swing.JLabel lbSenha;
    private javax.swing.JLabel lbTelefone;
    private javax.swing.JLabel lbTipoPermissao;
    private javax.swing.JLabel lbUsuarioBloqueado;
    private javax.swing.JTextField txtBairro;
    private javax.swing.JTextField txtCEP;
    private javax.swing.JTextField txtCPF;
    private javax.swing.JTextField txtCidade;
    private javax.swing.JTextField txtComplemento;
    private javax.swing.JTextField txtDataCriacao;
    private javax.swing.JTextField txtDataNasc;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtLogin;
    private javax.swing.JTextField txtLogradouro;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtNumero;
    private javax.swing.JPasswordField txtSenha;
    private javax.swing.JTextField txtTelefone;
    private javax.swing.JTextField txtUsuarioBloqueado;
    // End of variables declaration//GEN-END:variables

    
}
