package View;

import View.Sobre;
import ConexaoDao.ModuloConexao;
import java.sql.*;
import java.text.DateFormat;
import javax.swing.JOptionPane;

/**
 *
 * @author cintia - debora - isabela
 */
public class MenuPrincipal extends javax.swing.JFrame {

    // usando a variavel conexao do DAO
    Connection conexao = null;
    // criando variaveis especiais para conexão com o banco
    //Prepared Statemente e ResultSet são frameworks do pacote java.sql
    // e servem para preparar e executar as instruções SQL
    PreparedStatement pst = null;
    ResultSet rs = null;
    
    public MenuPrincipal() {
        initComponents();
        //estabelecendo a conexÃo com o banco sempre nesse ponto
        conexao = ModuloConexao.conector();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblData = new javax.swing.JLabel();
        lblUsuario = new javax.swing.JLabel();
        menu = new javax.swing.JMenuBar();
        menuCad = new javax.swing.JMenu();
        menuQuadra = new javax.swing.JMenuItem();
        menuManutencao = new javax.swing.JMenuItem();
        menuUsu = new javax.swing.JMenuItem();
        menuRel = new javax.swing.JMenu();
        menuFinanceiro = new javax.swing.JMenuItem();
        menuReserva = new javax.swing.JMenuItem();
        menuPlan = new javax.swing.JMenu();
        menuPromo = new javax.swing.JMenuItem();
        menuAjuda = new javax.swing.JMenu();
        menuSobre = new javax.swing.JMenuItem();
        menuOpc = new javax.swing.JMenu();
        menuSair = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Tenis Clube Beach");
        setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblData.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        lblData.setText("Data");
        getContentPane().add(lblData, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 50, -1, -1));

        lblUsuario.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        lblUsuario.setText("Usuário");
        getContentPane().add(lblUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 10, -1, -1));

        menu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        menuCad.setText("Cadastro");
        menuCad.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        menuQuadra.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Q, java.awt.event.InputEvent.ALT_DOWN_MASK));
        menuQuadra.setFont(new java.awt.Font("Segoe UI", 0, 17)); // NOI18N
        menuQuadra.setText("Quadra");
        menuQuadra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuQuadraActionPerformed(evt);
            }
        });
        menuCad.add(menuQuadra);

        menuManutencao.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.ALT_DOWN_MASK));
        menuManutencao.setFont(new java.awt.Font("Segoe UI", 0, 17)); // NOI18N
        menuManutencao.setText("Manutenção");
        menuManutencao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuManutencaoActionPerformed(evt);
            }
        });
        menuCad.add(menuManutencao);

        menuUsu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_U, java.awt.event.InputEvent.ALT_DOWN_MASK));
        menuUsu.setFont(new java.awt.Font("Segoe UI", 0, 17)); // NOI18N
        menuUsu.setText("Usuário");
        menuUsu.setEnabled(false);
        menuUsu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuUsuActionPerformed(evt);
            }
        });
        menuCad.add(menuUsu);

        menu.add(menuCad);

        menuRel.setText("Relatórios");
        menuRel.setEnabled(false);
        menuRel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        menuRel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuRelActionPerformed(evt);
            }
        });

        menuFinanceiro.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F, java.awt.event.InputEvent.ALT_DOWN_MASK));
        menuFinanceiro.setFont(new java.awt.Font("Segoe UI", 0, 17)); // NOI18N
        menuFinanceiro.setText("Financeiro");
        menuFinanceiro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuFinanceiroActionPerformed(evt);
            }
        });
        menuRel.add(menuFinanceiro);

        menuReserva.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.ALT_DOWN_MASK));
        menuReserva.setFont(new java.awt.Font("Segoe UI", 0, 17)); // NOI18N
        menuReserva.setText("Reserva");
        menuReserva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuReservaActionPerformed(evt);
            }
        });
        menuRel.add(menuReserva);

        menu.add(menuRel);

        menuPlan.setText("Planejamento");
        menuPlan.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        menuPromo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_P, java.awt.event.InputEvent.ALT_DOWN_MASK));
        menuPromo.setFont(new java.awt.Font("Segoe UI", 0, 17)); // NOI18N
        menuPromo.setText("Promoções");
        menuPromo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuPromoActionPerformed(evt);
            }
        });
        menuPlan.add(menuPromo);

        menu.add(menuPlan);

        menuAjuda.setText("Ajuda");
        menuAjuda.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        menuSobre.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.ALT_DOWN_MASK));
        menuSobre.setFont(new java.awt.Font("Segoe UI", 0, 17)); // NOI18N
        menuSobre.setText("Sobre");
        menuSobre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuSobreActionPerformed(evt);
            }
        });
        menuAjuda.add(menuSobre);

        menu.add(menuAjuda);

        menuOpc.setText("Opções");
        menuOpc.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        menuSair.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        menuSair.setFont(new java.awt.Font("Segoe UI", 0, 17)); // NOI18N
        menuSair.setText("Sair");
        menuSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuSairActionPerformed(evt);
            }
        });
        menuOpc.add(menuSair);

        menu.add(menuOpc);

        setJMenuBar(menu);

        setSize(new java.awt.Dimension(1166, 746));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void menuManutencaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuManutencaoActionPerformed
        // chamando a tela manutenção
        Manutencao tela = new Manutencao ();
        tela.setVisible(true);
    }//GEN-LAST:event_menuManutencaoActionPerformed

    private void menuFinanceiroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuFinanceiroActionPerformed
        // chamando a tela financeiro
        Financeiro tela = new Financeiro();
        tela.setVisible(true);
    }//GEN-LAST:event_menuFinanceiroActionPerformed

    private void menuSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSairActionPerformed
        // fecha a tela
        int sair = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja sair?","Atenção!!",JOptionPane.YES_NO_OPTION);
        if (sair == JOptionPane.YES_OPTION){  
            System.exit(0);
        }
    }//GEN-LAST:event_menuSairActionPerformed

    private void menuPromoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuPromoActionPerformed
        // chamando a tela planejamento
        
        Planejamento tela = new Planejamento();
        tela.setVisible(true);
    }//GEN-LAST:event_menuPromoActionPerformed

    private void menuQuadraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuQuadraActionPerformed
        // chamando a tela quadra
        
        Quadra tela = new Quadra();
        tela.setVisible(true);
    }//GEN-LAST:event_menuQuadraActionPerformed

    private void menuUsuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuUsuActionPerformed
        // chamando a tela cadastro usuario
        CadastroUsuario tela = new CadastroUsuario();
        tela.setVisible(true);
    }//GEN-LAST:event_menuUsuActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // comando para maximizar a tela 
        /*this.setExtendedState(MAXIMIZED_BOTH);*/
    }//GEN-LAST:event_formWindowOpened

    private void menuSobreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSobreActionPerformed
        // Chamando a tela sobre
        Sobre tela = new Sobre ();
        tela.setVisible(true);
    }//GEN-LAST:event_menuSobreActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // substituindo a data pela data atual do sistema ao inicializar
        java.util.Date data = new java.util.Date ();
        DateFormat mudador = DateFormat.getDateInstance(DateFormat.SHORT);
        lblData.setText(mudador.format(data));
    }//GEN-LAST:event_formWindowActivated

    private void menuRelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuRelActionPerformed
        /*
        
        */
    }//GEN-LAST:event_menuRelActionPerformed

    private void menuReservaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuReservaActionPerformed
        // chamando a tela reserva
        Reserva tela = new Reserva ();
        tela.setVisible(true);
       
    }//GEN-LAST:event_menuReservaActionPerformed
    
    public static void main(String args[]) {
      try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lblData;
    public static javax.swing.JLabel lblUsuario;
    private javax.swing.JMenuBar menu;
    private javax.swing.JMenu menuAjuda;
    private javax.swing.JMenu menuCad;
    public static javax.swing.JMenuItem menuFinanceiro;
    public static javax.swing.JMenuItem menuManutencao;
    private javax.swing.JMenu menuOpc;
    private javax.swing.JMenu menuPlan;
    private javax.swing.JMenuItem menuPromo;
    public static javax.swing.JMenuItem menuQuadra;
    public static javax.swing.JMenu menuRel;
    public static javax.swing.JMenuItem menuReserva;
    private javax.swing.JMenuItem menuSair;
    private javax.swing.JMenuItem menuSobre;
    public static javax.swing.JMenuItem menuUsu;
    // End of variables declaration//GEN-END:variables
}
