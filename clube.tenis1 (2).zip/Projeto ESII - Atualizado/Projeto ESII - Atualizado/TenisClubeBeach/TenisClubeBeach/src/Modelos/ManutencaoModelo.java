package Modelos;

import java.util.Date;

/**
 *
 * @author cintia - déborah - isabela
 */
public class ManutencaoModelo {
    
    //atributos
    protected Date dia;
    protected Date agendarPara;
    protected Date horario;
    protected boolean alterarData;
    protected boolean cancelarManutencao;
    protected int idquad;
    
    //construtor

    public ManutencaoModelo() {
    }
    
    
    
    //getters e setters
    public Date getDia() {
        return dia;
    }

    public void setDia(Date dia) {
        this.dia = dia;
    }

    public Date getAgendarPara() {
        return agendarPara;
    }

    public void setAgendarPara(Date agendarPara) {
        this.agendarPara = agendarPara;
    }

    public Date getHorario() {
        return horario;
    }

    public void setHorario(Date horario) {
        this.horario = horario;
    }

    public boolean isAlterarData() {
        return alterarData;
    }

    public void setAlterarData(boolean alterarData) {
        this.alterarData = alterarData;
    }

    public boolean isCancelarManutencao() {
        return cancelarManutencao;
    }

    public void setCancelarManutencao(boolean cancelarManutencao) {
        this.cancelarManutencao = cancelarManutencao;
    }

    public int getIdquad() {
        return idquad;
    }

    public void setIdquad(int idquad) {
        this.idquad = idquad;
    }
    
}
