package Modelos;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cintia
 */
public class Usuario extends Pessoa {
    
    // atributos
    
    protected Date dataCriacao;
    protected boolean usuBloqueado;
    protected String tipoPermissao;

    
    
    // construtores

    public Usuario(int id, String nomeCompleto, String cpf, String dataNascimento, char genero, String telefone, String email, String cep, String logradouro, String cidade, String estado,String perfil, String dataCriacao, boolean usuBloqueado, String tipoPermissao) {
        //costrutor da classe PAI (pessoa)
        super(id, nomeCompleto, cpf, dataNascimento, genero, telefone, email, cep, logradouro, cidade, estado,perfil);
        try {
            this.dataCriacao = new SimpleDateFormat("dd/MM/yyyy").parse(dataCriacao);
        } catch (ParseException ex) {
            Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.usuBloqueado = usuBloqueado;
        this.tipoPermissao = tipoPermissao;
        
        
    }
    
    // criando um cliente com construtores especificos (menos informações)

    public Usuario(int id, String nomeCompleto,String dataCriacao, boolean usuBloqueado, String tipoPermissao) {
        super(id, nomeCompleto);
        try {
            this.dataCriacao = new SimpleDateFormat("dd/MM/yyyy").parse(dataCriacao);
        } catch (ParseException ex) {
            Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.usuBloqueado = usuBloqueado;
        this.tipoPermissao = tipoPermissao;
       
    }
    
    //acessando os dados as informações da classe de fora
    // getters e setters

    public Date getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(Date dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public boolean isUsuBloqueado() {
        return usuBloqueado;
    }

    public void setUsuBloqueado(boolean usuBloqueado) {
        this.usuBloqueado = usuBloqueado;
    }

    public String getTipoPermissao() {
        return tipoPermissao;
    }

    public void setTipoPermissao(String tipoPermissao) {
        this.tipoPermissao = tipoPermissao;
    }

  

}