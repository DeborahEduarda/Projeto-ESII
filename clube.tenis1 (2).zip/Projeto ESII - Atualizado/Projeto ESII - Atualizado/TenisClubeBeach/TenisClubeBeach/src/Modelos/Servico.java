package Modelos;

/**
 *
 * @author cintia
 */
public class Servico {
    
    
    //atributos
    
    private int id;
    private String descricao;
    private float valor;
    
    //construtor

    public Servico(int id, String descricao, float valor) {
        this.id = id;
        this.descricao = descricao;
        this.valor = valor;
    }
    
    //acessando os dados as informações da classe de fora
    // getters e setters

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }
    
    
    
}

