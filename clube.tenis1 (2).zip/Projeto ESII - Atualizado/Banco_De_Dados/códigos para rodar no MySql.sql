-- a linha a baixo cria banco de dados
create database dbclube;
-- a linha abaixo escolhe o banco de dados
use dbclube;
-- abaixo cria uma tabela
create table tbusuarios (
iduser int primary key,
usuario varchar(50),
fone varchar(50),
login varchar(15) not null unique,
senha varchar(15) not null
);
-- comando para descrever tabela
describe tbusuarios;
-- abaixo inserir dados na tabela (CRUD)
-- Create -> insert
insert into tbusuarios (iduser,usuario,fone,login,senha)
values (1, 'Déborah', '98888-8888','deborha9','123456');
-- linha abaixo exibe os dados da tabela (CRUD)
-- Read -> select
select * from tbusuarios;
insert into tbusuarios (iduser,usuario,fone,login,senha)
values (2, 'administrador', '94885-4786','admin1','123456');
insert into tbusuarios (iduser,usuario,fone,login,senha)
values (3, 'zelador', '97284-3638','zelar21','123456');
-- a linha abaixo modifica dados da tabela (CRUD)
-- update -update
update tbusuarios set fone='99999-9999' where iduser=2;
-- a linha abaixo apaga um registro da tabela (CRUD)
-- delete -> delete
delete from tbusuarios where iduser=3;

select * from tbusuarios;

create table tbclientes(
idcli int primary key auto_increment,
nomecli varchar(20) not null,
endcli varchar(100),
fonecli varchar(50) not null,
emailcli varchar(50)
);
describe tbclientes;

insert into tbclientes (nomecli, endcli,fonecli,emailcli)
values('Floriano Jose', 'Avenida Brasil, 123', '98888-8888','florianoJose@gmail.com');

select*from tbclientes;
