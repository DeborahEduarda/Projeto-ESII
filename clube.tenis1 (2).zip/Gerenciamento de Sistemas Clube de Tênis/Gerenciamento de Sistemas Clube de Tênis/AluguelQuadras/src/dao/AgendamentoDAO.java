package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import mapeamento.Agendamento;
import utilitario.Conectar;

/**
 *
 * @author cintia
 */
public class AgendamentoDAO {
    public void cadastrar (Agendamento a){
         Connection con = Conectar.getConectar();
         String sql = "insert into tbagendamento (quadra,cliente,data,horarioInicio,horarioFim) values (?,?,?,?,?)";
         try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setString (1, a.getQuadra().toString());
             pstm.setString(2, a.getCliente().toString());
             pstm.setString(3, a.getData());
             pstm.setString(4, a.getHorarioInicio());
             pstm.setString(5, a.getHorarioFim());
             pstm.executeUpdate();
             pstm.close();
             con.close();
            JOptionPane.showMessageDialog(null,"Cadastrado com sucesso!!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,"Erro ao cadastrar!!");
        }
    }
    public void atualizar (Agendamento a){
        Connection con = Conectar.getConectar();
        String sql = "update tbagendamento quadra=?,cliente=?,data=?,horarioInicio=?,horarioFim=? where id_Agendamento=?";
        try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setString(1, a.getQuadra());
             pstm.setString(2, a.getCliente());
             pstm.setString(3, a.getData());
             pstm.setString(4, a.getHorarioInicio());
             pstm.setString(5, a.getHorarioFim());
             pstm.setInt (6, a.getId_Agendamento());
             pstm.executeUpdate();
             pstm.close();
             con.close();
             JOptionPane.showMessageDialog(null,"Atualizado com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao atualizar registro!!");
        }
    }
    public void excluir (Agendamento a){
        Connection con = Conectar.getConectar(); 
        String sql ="delete from tbagendamento where id_Agendamento=?";
        int opcao = JOptionPane.showConfirmDialog(null, "Deseja excluir cliente?"+a.getCliente()+"?","Excluir",JOptionPane.YES_NO_OPTION);
        if (opcao == JOptionPane.YES_OPTION){
            try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setInt(1, a.getId_Agendamento());
             pstm.executeUpdate();
             pstm.close();
             con.close();
             JOptionPane.showMessageDialog(null,"Excluido com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao excluir registro!!");
        }
        }
       
    }
    public List<Agendamento> listarTodos(){
        Connection con = Conectar.getConectar();
        List<Agendamento> lista = new ArrayList<>();
        String sql = "select *from tbagendamento order by quadra";
        try (PreparedStatement pstm = con.prepareStatement(sql)){
           ResultSet resultado = pstm.executeQuery();
           while(resultado.next()){
               Agendamento a = new Agendamento ();
               a.setId_Agendamento(resultado.getInt("id_Agendamento"));
               a.setQuadra(resultado.getString("quadra"));
               a.setCliente(resultado.getString("cliente"));
               a.setData(resultado.getString("data"));
               a.setHorarioInicio(resultado.getString("horarioInicio"));
               a.setHorarioFim(resultado.getString("horarioFim"));
               lista.add(a);
               
           }
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar os registros");
        }
        
        return lista;
    }
   
}
