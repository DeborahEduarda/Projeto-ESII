package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import mapeamento.Cliente;
import mapeamento.Reserva;
import utilitario.Conectar;

/**
 *
 * @author cintia
 */
public class ReservaDAO {
    public void cadastrar (Reserva r){
         Connection con = Conectar.getConectar();
         String sql = "insert into tbreserva (formaPagamento) values (?)";
         try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setString(1, r.getFormaPagamento());
             pstm.executeUpdate();
             pstm.close();
             con.close();
            JOptionPane.showMessageDialog(null,"Cadastrado com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao cadastrar!!");
        }
    }
    public void atualizar (Reserva r){
        Connection con = Conectar.getConectar();
        String sql = "update tbreserva formaPagamento=? where id_reserva=?";
        try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setString(1, r.getFormaPagamento());
             pstm.setString (2, r.getId_reserva());
             pstm.executeUpdate();
             pstm.close();
             con.close();
             JOptionPane.showMessageDialog(null,"Atualizado com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao atualizar registro!!");
        }
    }
    public void excluir (Reserva r){
        Connection con = Conectar.getConectar();
        String sql ="delete from tbreserva where id_reserva?";
        int opcao = JOptionPane.showConfirmDialog(null, "Deseja excluir cliente?"+r.getId_reserva()+"?","Excluir",JOptionPane.YES_NO_OPTION);
        if (opcao == JOptionPane.YES_OPTION){
            try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setString(1, r.getId_reserva());
             pstm.executeUpdate();
             pstm.close();
             con.close();
             JOptionPane.showMessageDialog(null,"excluido com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao excluir registro!!");
        }
        }
       
    }
    public List<Reserva> listarTodos(){
        Connection con = Conectar.getConectar();
        List<Reserva> lista = new ArrayList<>();
        String sql = "select *from tbreserva order by nome";
        try (PreparedStatement pstm = con.prepareStatement(sql)){
           ResultSet resultado = pstm.executeQuery();
           while(resultado.next()){
               Reserva r = new Reserva ();
               r.setId_reserva(resultado.getString("id_reserva"));
               r.setFormaPagamento(resultado.getString("formaPagamento"));
               
               lista.add(r);
               
           }
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar os registros");
        }
        
        return lista;
    }
}
