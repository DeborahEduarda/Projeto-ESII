package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import mapeamento.Cliente;
import utilitario.Conectar;

/**
 *
 * @author cintia
 */
public class ClienteDAO {
    public void cadastrar (Cliente c){
         Connection con = Conectar.getConectar();
         String sql = "insert into tbcliente (nome,cpf,genero,email,dataNascimento) values (?,?,?,?,?)";
         try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setString(1, c.getNome());
             pstm.setString(2, c.getCpf());
             pstm.setString(3, c.getGenero());
             pstm.setString(4, c.getEmail());
             pstm.setString(5, c.getDataNascimento().toString());
             pstm.executeUpdate();
             pstm.close();
             con.close();
            JOptionPane.showMessageDialog(null,"Cadastrado com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao cadastrar!!");
        }
    }
    public void atualizar (Cliente c){
        Connection con = Conectar.getConectar();
        String sql = "update tbcliente nome=?,cpf=?,genero=?,email=?,dataNascimento=? where id_cliente=?";
        try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setString(1, c.getNome());
             pstm.setString(2, c.getCpf());
             pstm.setString(3, c.getGenero());
             pstm.setString(4, c.getEmail());
             pstm.setString(5, c.getDataNascimento().toString());
             pstm.setInt (6, c.getId_cliente());
             pstm.executeUpdate();
             pstm.close();
             con.close();
             JOptionPane.showMessageDialog(null,"Atualizado com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao atualizar registro!!");
        }
    }
    public void excluir (Cliente c){
        Connection con = Conectar.getConectar();
        String sql ="delete from tbcliente where id_cliente?";
        int opcao = JOptionPane.showConfirmDialog(null, "Deseja excluir cliente?"+c.getNome()+"?","Excluir",JOptionPane.YES_NO_OPTION);
        if (opcao == JOptionPane.YES_OPTION){
            try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setInt(1, c.getId_cliente());
             pstm.executeUpdate();
             pstm.close();
             con.close();
             JOptionPane.showMessageDialog(null,"excluido com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao excluir registro!!");
        }
        }
       
    }
    public List<Cliente> listarTodos(){
        Connection con = Conectar.getConectar();
        List<Cliente> lista = new ArrayList<>();
        String sql = "select *from tbcliente order by nome";
        try (PreparedStatement pstm = con.prepareStatement(sql)){
           ResultSet resultado = pstm.executeQuery();
           while(resultado.next()){
               Cliente c = new Cliente ();
               c.setId_cliente(resultado.getInt("id_cliente"));
               c.setNome(resultado.getString("nome"));
               c.setCpf(resultado.getString("cpf"));
               c.setGenero(resultado.getString("genero"));
               c.setEmail(resultado.getString("email"));
               c.setDataNascimento(resultado.getString("datanascimento"));
               lista.add(c);
               
           }
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar os registros");
        }
        
        return lista;
    }

    public void cadastrar(formularios.Cliente c) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
   
}
