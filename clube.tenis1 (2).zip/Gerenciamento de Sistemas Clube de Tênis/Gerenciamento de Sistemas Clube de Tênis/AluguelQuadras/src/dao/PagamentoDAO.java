package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import mapeamento.Pagamento;
import utilitario.Conectar;
import Enum.TipoPagamento;
import Enum.TipoQuadra;

/**
 *
 * @author cintia
 */
public class PagamentoDAO {
      public void cadastrar (Pagamento p){
         Connection con = Conectar.getConectar();
         String sql = "insert into tbpagamento (preco,totalPagar) values (?,?)";
         try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setString(1, p.getPreco());
             pstm.setString(2, p.getTotalPagar());
             pstm.executeUpdate();
             pstm.close();
             con.close();
            JOptionPane.showMessageDialog(null,"Cadastrado com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao cadastrar!!");
        }
    }
    public void atualizar (Pagamento p){
        Connection con = Conectar.getConectar();
        String sql = "update tbpagamento preco=?, totalPagar=? where id_Pagamento=?";
        try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setString(1, p.getPreco());
             pstm.setString(2, p.getTotalPagar());
             pstm.setInt (3, p.getId_Pagamento());
             pstm.executeUpdate();
             pstm.close();
             con.close();
             JOptionPane.showMessageDialog(null,"Atualizado com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao atualizar registro!!");
        }
    }
    public void excluir (Pagamento p){
        Connection con = Conectar.getConectar();
        String sql ="delete from tbpagamento where id_Pagamento?";
        int opcao = JOptionPane.showConfirmDialog(null, "Deseja excluir está manutenção?"+p.getId_Pagamento()+"?","Excluir",JOptionPane.YES_NO_OPTION);
        if (opcao == JOptionPane.YES_OPTION){
            try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setInt(1, p.getId_Pagamento());
             pstm.executeUpdate();
             pstm.close();
             con.close();
             JOptionPane.showMessageDialog(null,"Excluido com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao excluir registro!!");
        }
        }
       
    }
    public List<Pagamento> listarTodos(){
        Connection con = Conectar.getConectar();
        List<Pagamento> lista = new ArrayList<>();
        String sql = "select *from tbpagamento order by nome";
        try (PreparedStatement pstm = con.prepareStatement(sql)){
           ResultSet resultado = pstm.executeQuery();
           while(resultado.next()){
               Pagamento p = new Pagamento ();
               p.setId_Pagamento(resultado.getInt("id_Pagamento"));
               p.setPreco(resultado.getString("preco"));
               p.setTotalPagar(resultado.getString("totalPagar"));
               lista.add(p);
               
           }
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar os registros");
        }
        
        return lista;
    }
}
