package Enum;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
/**
 *
 * @author cintia
 */
public enum TipoQuadra {
        SAIBRO,
	RÁPIDA,
	BEACH_TENNIS
	
        
}
