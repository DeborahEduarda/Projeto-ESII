package mapeamento;

import java.time.LocalDate;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author cintia
 */
public class Usuario {
    
    private int id_Usuario;
    private String nome;
    private String email;
    private String senha;
    private String nivelAcesso;
    private String estaBloqueado;
    private String estaDesabilitado;
    private String dataCriacao;
    
    ArrayList <Usuario> usuarios = new ArrayList<Usuario>();

    public Usuario(int id_Usuario, String nome, String email, String senha, String nivelAcesso, String estaBloqueado, String estaDesabilitado, String dataCriacao) {
        this.id_Usuario = id_Usuario;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.nivelAcesso = nivelAcesso;
        this.estaBloqueado = estaBloqueado;
        this.estaDesabilitado = estaDesabilitado;
        this.dataCriacao = dataCriacao;
    }

    public Usuario() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
    
    public void cadastrar(int id_Usuario,String nome, String email, String senha, String nivelAcesso, String estaBloqueado, String estaDesabilitado, String dataCriacao) {
                this.setId_Usuario(id_Usuario);
                this.setNome(nome);
		this.setEmail(email);
		this.setSenha(senha);
                this.setEstaBloqueado(estaBloqueado);
                this.setEstaDesabilitado(estaDesabilitado);
                this.setDataCriacao(dataCriacao);
		usuarios.add(this);
	}

    public int getId_Usuario() {
        return id_Usuario;
    }

    public void setId_Usuario(int id_Usuario) {
        this.id_Usuario = id_Usuario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNivelAcesso() {
        return nivelAcesso;
    }

    public void setNivelAcesso(String nivelAcesso) {
        this.nivelAcesso = nivelAcesso;
    }

    public String getEstaBloqueado() {
        return estaBloqueado;
    }

    public void setEstaBloqueado(String estaBloqueado) {
        this.estaBloqueado = estaBloqueado;
    }

    public String getEstaDesabilitado() {
        return estaDesabilitado;
    }

    public void setEstaDesabilitado(String estaDesabilitado) {
        this.estaDesabilitado = estaDesabilitado;
    }

    public String getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(String dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    
   
   
    
    
}
