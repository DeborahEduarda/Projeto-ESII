package mapeamento;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 *
 * @author cintia
 */

public class Manutencao extends Agendamento{

    private int idManutencao;
    private String numeroQuadra;
    private String agendarPara;
    private String horario;

    public Manutencao(int idManutencao, String numeroQuadra, String agendarPara, String horario, int id_Agendamento, String quadra, String cliente, String data, String horarioInicio, String horarioFim) {
        super(id_Agendamento, quadra, cliente, data, horarioInicio, horarioFim);
        this.idManutencao = idManutencao;
        this.numeroQuadra = numeroQuadra;
        this.agendarPara = agendarPara;
        this.horario = horario;
    }

    public Manutencao() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
    public ArrayList<Agendamento> getAgendamentos() {
        return agendamentos;
    }
    

    public int getIdManutencao() {
        return idManutencao;
    }

    public void setIdManutencao(int idManutencao) {
        this.idManutencao = idManutencao;
    }

    public String getNumeroQuadra() {
        return numeroQuadra;
    }

    public void setNumeroQuadra(String numeroQuadra) {
        this.numeroQuadra = numeroQuadra;
    }

    public String getAgendarPara() {
        return agendarPara;
    }

    public void setAgendarPara(String agendarPara) {
        this.agendarPara = agendarPara;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    
    
    
}
