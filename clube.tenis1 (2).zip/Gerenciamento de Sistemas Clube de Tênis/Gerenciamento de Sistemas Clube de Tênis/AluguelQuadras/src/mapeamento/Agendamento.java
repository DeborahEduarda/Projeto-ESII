package mapeamento;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
/**
 *
 * @author cintia
 */
public class Agendamento {
        private int id_Agendamento;
        private String quadra;
	private String cliente;
	private String data;
	private String horarioInicio;
	private String horarioFim;

    public Agendamento(int id_Agendamento, String quadra, String cliente, String data, String horarioInicio, String horarioFim) {
        this.id_Agendamento = id_Agendamento;
        this.quadra = quadra;
        this.cliente = cliente;
        this.data = data;
        this.horarioInicio = horarioInicio;
        this.horarioFim = horarioFim;
    }

       
	
    ArrayList <Agendamento> agendamentos = new ArrayList<Agendamento>();

    public Agendamento() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    public void cadastrar(int id_Agendamento,Quadra quadra,Cliente cliente, String data, String horarioInicio, String horarioFim) {
                this.setId_Agendamento(id_Agendamento);
		this.setQuadra(quadra);
		this.setCliente(cliente);
		this.setData(data);
		this.setHorarioInicio(horarioInicio);
                this.setHorarioFim(horarioFim);
		agendamentos.add(this);
	}

    public int getId_Agendamento() {
        return id_Agendamento;
    }

    public void setId_Agendamento(int id_Agendamento) {
        this.id_Agendamento = id_Agendamento;
    }

    public String getQuadra() {
        return quadra;
    }

    public void setQuadra(String quadra) {
        this.quadra = quadra;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHorarioInicio() {
        return horarioInicio;
    }

    public void setHorarioInicio(String horarioInicio) {
        this.horarioInicio = horarioInicio;
    }

    public String getHorarioFim() {
        return horarioFim;
    }

    public void setHorarioFim(String horarioFim) {
        this.horarioFim = horarioFim;
    }

    private void setCliente(Cliente cliente) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void setQuadra(Quadra quadra) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    

      
}
