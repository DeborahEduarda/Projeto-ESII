package modelos;

import java.sql.*;
import moduloDAO.ConexaoDao;

/**
 *
 * @author cintia
 */
public class Dados {
    
    //array
    private Usuario mUsuario []= new Usuario [1000];
    private int conUsu = 0;
    
public Dados (){
    
    Usuario mUsuarios = new Usuario("2022-06-04","cintia","cintia@cintia.com","123","123","true","false","HU 7 a 12 – gestor de usuários");
    mUsuario[conUsu] = mUsuarios;
    conUsu ++;
}
    
    public boolean validarUsuario (String usuario, String senha){
        boolean aux = false;
        for (int i = 0; i<conUsu; i++){
            if(mUsuario[i].getNome().equals(usuario)&& mUsuario[i].getSenha().equals(senha)){
                return true ;
            }
        }
       return false;
        

/*
        // método para quando abertar o botão de entrar na tela login
        // será feita está validação/confirmação do usuario
        // criando uma condição para acessar o sistema
        if (usuario.equals("cintia") && senha.equals("1234")){
            return true;
        }else{
            return false;
        }
        */
    }
    
}
