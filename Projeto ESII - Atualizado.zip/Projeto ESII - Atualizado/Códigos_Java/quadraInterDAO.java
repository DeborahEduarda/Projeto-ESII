package interDAO;

/**
 *
 * * @author cintia - debora - isabela
 */

public class quadraInterDAO {
    private int idquad;
    private String nomequadra;
    private String preco;
    private String bancoquad;
    private String arquibancada;
    private String quadcoberta;
    private String tipoquad;

    public int getIdquad() {
        return idquad;
    }

    public void setIdquad(int idquad) {
        this.idquad = idquad;
    }

    public String getNomequadra() {
        return nomequadra;
    }

    public void setNomequadra(String nomequadra) {
        this.nomequadra = nomequadra;
    }

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }

    public String getBancoquad() {
        return bancoquad;
    }

    public void setBancoquad(String bancoquad) {
        this.bancoquad = bancoquad;
    }

    public String getArquibancada() {
        return arquibancada;
    }

    public void setArquibancada(String arquibancada) {
        this.arquibancada = arquibancada;
    }

    public String getQuadcoberta() {
        return quadcoberta;
    }

    public void setQuadcoberta(String quadcoberta) {
        this.quadcoberta = quadcoberta;
    }

    public String getTipoquad() {
        return tipoquad;
    }

    public void setTipoquad(String tipoquad) {
        this.tipoquad = tipoquad;
    }

}