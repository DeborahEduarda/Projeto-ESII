package View;

import ConexaoDao.ModuloConexao;
import Modelos.Cliente;
import Modelos.Reservando;
import Modelos.Servico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.*;
import javax.swing.JComboBox;
import javax.swing.JTextField;

/**
 *
 * @author cintia - debora - isabela
 */
public class Reserva extends javax.swing.JFrame {

   // usando a variavel conexao do DAO
    Connection conexao = null;
    // criando variaveis especiais para conexão com o banco
    //Prepared Statemente e ResultSet são frameworks do pacote java.sql
    // e servem para preparar e executar as instruções SQL
    PreparedStatement pst = null;
    ResultSet rs = null;
    
       
    public Reserva() {
        initComponents();
        //estabelecendo a conexÃo com o banco sempre nesse ponto
        conexao = ModuloConexao.conector();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblServico = new javax.swing.JLabel();
        lblValor = new javax.swing.JLabel();
        lblData = new javax.swing.JLabel();
        lblHoraInicio = new javax.swing.JLabel();
        lblHoraFim = new javax.swing.JLabel();
        lblId = new javax.swing.JLabel();
        txtServico = new javax.swing.JTextField();
        txtValor = new javax.swing.JTextField();
        txtData = new javax.swing.JTextField();
        txtHoraInicio = new javax.swing.JTextField();
        txtHoraFim = new javax.swing.JTextField();
        txtId = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblTabela = new javax.swing.JTable();
        btnPesquisar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        btnEditar1 = new javax.swing.JButton();
        lblPagamento = new javax.swing.JLabel();
        txtCancelarReserva = new javax.swing.JComboBox<>();
        lblUsuAtrasado = new javax.swing.JLabel();
        lblCancelarReserva = new javax.swing.JLabel();
        txtUsuAtrasado = new javax.swing.JComboBox<>();
        txtPagamento = new javax.swing.JComboBox<>();
        lblTransparente = new javax.swing.JLabel();
        lblFund = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Reserva");
        setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblServico.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lblServico.setForeground(new java.awt.Color(255, 255, 255));
        lblServico.setText("Serviço");
        getContentPane().add(lblServico, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 70, -1));

        lblValor.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lblValor.setForeground(new java.awt.Color(255, 255, 255));
        lblValor.setText("Valor R$");
        getContentPane().add(lblValor, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 80, -1));

        lblData.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lblData.setForeground(new java.awt.Color(255, 255, 255));
        lblData.setText("Data");
        getContentPane().add(lblData, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 50, -1));

        lblHoraInicio.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lblHoraInicio.setForeground(new java.awt.Color(255, 255, 255));
        lblHoraInicio.setText("Hora Início");
        getContentPane().add(lblHoraInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 100, -1));

        lblHoraFim.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lblHoraFim.setForeground(new java.awt.Color(255, 255, 255));
        lblHoraFim.setText("Hora Fim");
        getContentPane().add(lblHoraFim, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, 80, -1));

        lblId.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lblId.setForeground(new java.awt.Color(255, 255, 255));
        lblId.setText("Id");
        getContentPane().add(lblId, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 30, -1));

        txtServico.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtServico, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 170, 280, -1));

        txtValor.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtValor, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 210, 280, -1));

        txtData.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtData, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 250, 280, -1));

        txtHoraInicio.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtHoraInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 290, 280, -1));

        txtHoraFim.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtHoraFim, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 330, 280, -1));

        txtId.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        getContentPane().add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, 280, -1));

        tblTabela.setFont(new java.awt.Font("Segoe UI", 0, 17)); // NOI18N
        tblTabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Cliente", "Serviço", "Valor R$", "Data", "Hora Início", "Hora Fim", "Pgto"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblTabela.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jScrollPane2.setViewportView(tblTabela);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, 760, 130));

        btnPesquisar.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        btnPesquisar.setText("Pesquisar");
        getContentPane().add(btnPesquisar, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 580, -1, -1));

        btnExcluir.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        btnExcluir.setText("Excluir");
        getContentPane().add(btnExcluir, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 580, -1, 30));

        btnEditar.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        btnEditar.setText("Editar");
        getContentPane().add(btnEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 580, -1, -1));

        btnSair.setText("Sair");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });
        getContentPane().add(btnSair, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 10, -1, -1));

        btnEditar1.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        btnEditar1.setText("Salvar");
        getContentPane().add(btnEditar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 580, -1, -1));

        lblPagamento.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblPagamento.setForeground(new java.awt.Color(255, 255, 255));
        lblPagamento.setText("Forma de pagamento");
        getContentPane().add(lblPagamento, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 300, -1, -1));

        txtCancelarReserva.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtCancelarReserva.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "Sim", "Não" }));
        getContentPane().add(txtCancelarReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 260, 190, -1));

        lblUsuAtrasado.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblUsuAtrasado.setForeground(new java.awt.Color(255, 255, 255));
        lblUsuAtrasado.setText("Usuário atrasado");
        getContentPane().add(lblUsuAtrasado, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 160, -1, -1));

        lblCancelarReserva.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblCancelarReserva.setForeground(new java.awt.Color(255, 255, 255));
        lblCancelarReserva.setText("Cancelar reserva");
        getContentPane().add(lblCancelarReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 230, -1, -1));

        txtUsuAtrasado.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtUsuAtrasado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "Sim", "Não" }));
        getContentPane().add(txtUsuAtrasado, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 190, 190, -1));

        txtPagamento.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtPagamento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "Cartão de Crédito", "Cartão de Débito", "Dinheiro", "PIX", "Outros" }));
        getContentPane().add(txtPagamento, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 330, 190, -1));

        lblTransparente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Imagem/Agenda-PainelFundo.png"))); // NOI18N
        getContentPane().add(lblTransparente, new org.netbeans.lib.awtextra.AbsoluteConstraints(-50, -10, 840, 690));

        lblFund.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Imagem/raquetes.jpg"))); // NOI18N
        getContentPane().add(lblFund, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, 680));

        setSize(new java.awt.Dimension(796, 684));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        // fecha a tela
        System.exit(0);
    }//GEN-LAST:event_btnSairActionPerformed

   
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Reserva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Reserva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Reserva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Reserva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Reserva().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEditar1;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnPesquisar;
    private javax.swing.JButton btnSair;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblCancelarReserva;
    private javax.swing.JLabel lblData;
    private javax.swing.JLabel lblFund;
    private javax.swing.JLabel lblHoraFim;
    private javax.swing.JLabel lblHoraInicio;
    private javax.swing.JLabel lblId;
    private javax.swing.JLabel lblPagamento;
    private javax.swing.JLabel lblServico;
    private javax.swing.JLabel lblTransparente;
    private javax.swing.JLabel lblUsuAtrasado;
    private javax.swing.JLabel lblValor;
    private javax.swing.JTable tblTabela;
    private javax.swing.JComboBox<String> txtCancelarReserva;
    private javax.swing.JTextField txtData;
    private javax.swing.JTextField txtHoraFim;
    private javax.swing.JTextField txtHoraInicio;
    private javax.swing.JTextField txtId;
    private javax.swing.JComboBox<String> txtPagamento;
    private javax.swing.JTextField txtServico;
    private javax.swing.JComboBox<String> txtUsuAtrasado;
    private javax.swing.JTextField txtValor;
    // End of variables declaration//GEN-END:variables

   
}
