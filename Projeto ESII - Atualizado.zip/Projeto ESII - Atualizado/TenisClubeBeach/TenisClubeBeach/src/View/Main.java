package View;

import Modelos.Cliente;
import Modelos.Reservando;
import Modelos.Servico;
import Modelos.Usuario;
import java.sql.Connection;
import java.sql.DriverManager;


/**
 *
 * @author cintia
 */
public class Main {
    // está classe é exclusiva para testes
    
    //método estático
    public static void main(String[] args) {
        
        String nome = "Cíntia";
        System.out.println(nome);
        
        //tipo de variável serviço com objeto aluguel de quadra
        
        Servico servico = new Servico(0, "aluguel quadra",70);
        
        System.out.println(servico.getDescricao());
        System.out.println(servico.getValor());
        
    }
}
