package Modelos;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author cintia
 */
public class Reservando {
    
    // atributos
    
    protected int id;
    protected Cliente cliente; // dentro da variável cliente é guardado o objeto cliente
    protected Servico servico; // dentro da variável servico é guardado o objeto servico
    protected float valor;
    protected Date data;
    protected Date horaInicio;
    protected Date horaFim;
    protected boolean usuAtrasado;
    protected boolean cancelarReserva;
    protected String formaPagamento;
  
    
    // construtores
    // somente no construtor é utilizado String em: data, hora inicio e hora fim para uma melhor didática (todas as classes)
    
    public Reservando(int id, Cliente cliente, Servico servico, float valor, String data, String horaInicio, String horaFim, String formaPagamento) {
        this.id = id;
        this.cliente = cliente;
        this.servico = servico;
        this.valor = valor;
        try {
            this.data = new SimpleDateFormat("dd/MM/yyyy").parse(data);
        } catch (ParseException ex) {
            Logger.getLogger(Reservando.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            this.horaInicio = new SimpleDateFormat("HH:mm").parse(horaInicio);
        } catch (ParseException ex) {
            Logger.getLogger(Reservando.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            this.horaFim = new SimpleDateFormat("HH:mm").parse(horaFim);
        } catch (ParseException ex) {
            Logger.getLogger(Reservando.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.formaPagamento = formaPagamento;
    }

       
    //acessando os dados as informações da classe de fora
    // getters e setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Servico getServico() {
        return servico;
    }

    public void setServico(Servico servico) {
        this.servico = servico;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Date getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(Date horaInicio) {
        this.horaInicio = horaInicio;
    }

    public Date getHoraFim() {
        return horaFim;
    }

    public void setHoraFim(Date horaFim) {
        this.horaFim = horaFim;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }
    
}
