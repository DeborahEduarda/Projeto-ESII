package Modelos;

import java.util.Date;

/**
 *
 * @author cintia
 */
public class Cliente extends Pessoa {
    
    // atributos
    
    protected String numero;
    protected String complemento;
    protected String bairro;
    protected String login;
    protected String senha;
     
    
                    
    // construtores

    public Cliente(String numero, String complemento, String bairro, String login, String senha, int id, String nome, String cpf, String dataNascimento, char genero, String telefone, String email, String cep, String logradouro, String cidade, String estado, String perfil) {
        super(id, nome, cpf, dataNascimento, genero, telefone, email, cep, logradouro, cidade, estado, perfil);
        this.numero = numero;
        this.complemento = complemento;
        this.bairro = bairro;
        this.login = login;
        this.senha = senha;
    }


    // criando um cliente com construtores especificos (menos informações)

    public Cliente(String numero, String complemento, String bairro, String login, String senha, String perfil, int id, String nome) {
        super(id, nome);
        this.numero = numero;
        this.complemento = complemento;
        this.bairro = bairro;
        this.login = login;
        this.senha = senha;
      
    }

    //acessando os dados as informações da classe de fora
    // getters e setters

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

   
    
   
}
    
    
    
    

   

    

