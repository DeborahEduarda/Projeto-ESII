package Modelos;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cintia
 */

//classe abstrata, não pode ser instanciada, é como se fosse intermediadora das classes filhas cliente e usuário

abstract public class Pessoa {
    
    // atributos
    
    protected int id;
    protected String nome;
    protected String cpf;
    protected Date dataNascimento;
    protected char genero;
    protected String telefone;
    protected String email;
    protected String cep;
    protected String logradouro;
    protected String cidade;
    protected String estado;
    protected String perfil;
  
    // construtores

    public Pessoa(int id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    // criando pessoa com todas as informações
    
    public Pessoa(int id, String nome, String cpf, String dataNascimento, char genero, String telefone, String email, String cep, String logradouro, String cidade, String estado, String perfil) {
        this.id = id;
        this.nome = nome;
        this.cpf = cpf;
        try {
            this.dataNascimento = new SimpleDateFormat("dd/MM/yyyy").parse(dataNascimento);
        } catch (ParseException ex) {
            Logger.getLogger(Pessoa.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.genero = genero;
        this.telefone = telefone;
        this.email = email;
        this.cep = cep;
        this.logradouro = logradouro;
        this.cidade = cidade;
        this.estado = estado;
        this.perfil = perfil;
    }
    
     //acessando os dados as informações da classe de fora
    // getters e setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public char getGenero() {
        return genero;
    }

    public void setGenero(char genero) {
        this.genero = genero;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String estado) {
        this.perfil = perfil;
    }
    
    
    
    
    
    
    
    
    
    
    
}
