package ConexaoDao;

import java.sql.*;


/**
 *
 * @author cintia
 **/
public class ModuloConexao {
    
    
         //Metodo responsavel para estabelecer conexao com o banco de dados
    public static Connection conector(){
        Connection conexao = null;
        
       
        // a linha abaixo chama o Drive
        String DRIVER = "com.mysql.cj.jdbc.Driver";
        
        // armazenando informacoes referente ao banco
        String URL = "jdbc:mysql://localhost:3306/dbtenisclube";
        String USER = "root" ;
        String PASSWORD = "Palmeiras$14" ;
        
        // estabelecendo conexao com o banco
        try {
            Class.forName(DRIVER);
            conexao = DriverManager.getConnection(URL,USER,PASSWORD);
            return conexao;
           }catch (Exception e) {
               //a linha abaixo serve para saber onde estou errando
               //System.out.println(e);
               return null;
           }
    }
}
