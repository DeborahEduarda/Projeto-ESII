package telas;

import java.text.DateFormat;
import javax.swing.JOptionPane;


/**
 *
 * @author cintia
 */
public class MenuPrincipal extends javax.swing.JFrame {


    public MenuPrincipal() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblData = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuArquivo = new javax.swing.JMenu();
        menuArquivoCliente = new javax.swing.JMenuItem();
        menuPagamento = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        menuArquivoUsuario = new javax.swing.JMenuItem();
        menuArquivoQuadra = new javax.swing.JMenuItem();
        menuArquivoManutencao = new javax.swing.JMenuItem();
        menuArquivoReserva = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        menuArquivoAlterarSenha = new javax.swing.JMenuItem();
        menuArquivoAlterarUsuario = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        menuArquivoSair = new javax.swing.JMenuItem();
        menuMovimentos = new javax.swing.JMenu();
        menuMovimentosNovaReserva = new javax.swing.JMenuItem();
        menuMovimentosRelatorioReserva = new javax.swing.JMenuItem();
        menuMovimentosRelatorioPagamento = new javax.swing.JMenuItem();
        menuAjuda = new javax.swing.JMenu();
        menuAjudaSobre = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("MENU PRINCIPAL");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        lblData.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblData.setText("Data");

        menuArquivo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/database.png"))); // NOI18N
        menuArquivo.setText("Arquivo");
        menuArquivo.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N

        menuArquivoCliente.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.ALT_DOWN_MASK));
        menuArquivoCliente.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        menuArquivoCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/1376029_client_corporate lawyer_insurer_notary_person_icon.png"))); // NOI18N
        menuArquivoCliente.setText("Cliente");
        menuArquivo.add(menuArquivoCliente);

        menuPagamento.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_P, java.awt.event.InputEvent.ALT_DOWN_MASK));
        menuPagamento.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        menuPagamento.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/4288566_banking_bill_card_credit_expenditure_icon.png"))); // NOI18N
        menuPagamento.setText("Pagamento");
        menuArquivo.add(menuPagamento);
        menuArquivo.add(jSeparator1);

        menuArquivoUsuario.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_U, java.awt.event.InputEvent.ALT_DOWN_MASK));
        menuArquivoUsuario.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        menuArquivoUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/43573_clients_icon.png"))); // NOI18N
        menuArquivoUsuario.setText("Usuário");
        menuArquivoUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuArquivoUsuarioActionPerformed(evt);
            }
        });
        menuArquivo.add(menuArquivoUsuario);

        menuArquivoQuadra.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Q, java.awt.event.InputEvent.ALT_DOWN_MASK));
        menuArquivoQuadra.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        menuArquivoQuadra.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/6159273_isometric_paddle_ping pong_sport_table_icon.png"))); // NOI18N
        menuArquivoQuadra.setText("Quadra");
        menuArquivo.add(menuArquivoQuadra);

        menuArquivoManutencao.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.ALT_DOWN_MASK));
        menuArquivoManutencao.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        menuArquivoManutencao.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/2799202_problem_solving_fixed_support_customer_icon.png"))); // NOI18N
        menuArquivoManutencao.setText("Manutenção");
        menuArquivoManutencao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuArquivoManutencaoActionPerformed(evt);
            }
        });
        menuArquivo.add(menuArquivoManutencao);

        menuArquivoReserva.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.ALT_DOWN_MASK));
        menuArquivoReserva.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        menuArquivoReserva.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/5929216_appointment_calendar_date_event_schedule_icon.png"))); // NOI18N
        menuArquivoReserva.setText("Reserva");
        menuArquivo.add(menuArquivoReserva);
        menuArquivo.add(jSeparator2);

        menuArquivoAlterarSenha.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.ALT_DOWN_MASK));
        menuArquivoAlterarSenha.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        menuArquivoAlterarSenha.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/3592827_access_general_house key_key_lock key_icon.png"))); // NOI18N
        menuArquivoAlterarSenha.setText("Alterar Senha");
        menuArquivoAlterarSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuArquivoAlterarSenhaActionPerformed(evt);
            }
        });
        menuArquivo.add(menuArquivoAlterarSenha);

        menuArquivoAlterarUsuario.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        menuArquivoAlterarUsuario.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        menuArquivoAlterarUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/1376032_attorney_businessman_financier_lawyer_marketer_icon.png"))); // NOI18N
        menuArquivoAlterarUsuario.setText("Alterar Usuário");
        menuArquivoAlterarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuArquivoAlterarUsuarioActionPerformed(evt);
            }
        });
        menuArquivo.add(menuArquivoAlterarUsuario);
        menuArquivo.add(jSeparator3);

        menuArquivoSair.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        menuArquivoSair.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        menuArquivoSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/exit_icon.png"))); // NOI18N
        menuArquivoSair.setText("Sair");
        menuArquivoSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuArquivoSairActionPerformed(evt);
            }
        });
        menuArquivo.add(menuArquivoSair);

        jMenuBar1.add(menuArquivo);

        menuMovimentos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/money.png"))); // NOI18N
        menuMovimentos.setText("Movimentos");
        menuMovimentos.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N

        menuMovimentosNovaReserva.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        menuMovimentosNovaReserva.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        menuMovimentosNovaReserva.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-calendar-48.png"))); // NOI18N
        menuMovimentosNovaReserva.setText("Nova Reserva");
        menuMovimentos.add(menuMovimentosNovaReserva);

        menuMovimentosRelatorioReserva.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        menuMovimentosRelatorioReserva.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        menuMovimentosRelatorioReserva.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-roteiro-de-relatório-gráfico-48.png"))); // NOI18N
        menuMovimentosRelatorioReserva.setText("Relatório Reseva");
        menuMovimentosRelatorioReserva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuMovimentosRelatorioReservaActionPerformed(evt);
            }
        });
        menuMovimentos.add(menuMovimentosRelatorioReserva);

        menuMovimentosRelatorioPagamento.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_P, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        menuMovimentosRelatorioPagamento.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        menuMovimentosRelatorioPagamento.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-relatório-de-lucro-48.png"))); // NOI18N
        menuMovimentosRelatorioPagamento.setText("Relatório Pagamento");
        menuMovimentosRelatorioPagamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuMovimentosRelatorioPagamentoActionPerformed(evt);
            }
        });
        menuMovimentos.add(menuMovimentosRelatorioPagamento);

        jMenuBar1.add(menuMovimentos);

        menuAjuda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ajuda.png"))); // NOI18N
        menuAjuda.setText("Ajuda");
        menuAjuda.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N

        menuAjudaSobre.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.ALT_DOWN_MASK));
        menuAjudaSobre.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        menuAjudaSobre.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-sobre-mim-feminino-50.png"))); // NOI18N
        menuAjudaSobre.setText("Sobre");
        menuAjudaSobre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuAjudaSobreActionPerformed(evt);
            }
        });
        menuAjuda.add(menuAjudaSobre);

        jMenuBar1.add(menuAjuda);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(869, Short.MAX_VALUE)
                .addComponent(lblData)
                .addGap(97, 97, 97))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblData)
                .addContainerGap(628, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(1024, 724));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void menuArquivoAlterarSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuArquivoAlterarSenhaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuArquivoAlterarSenhaActionPerformed

    private void menuArquivoAlterarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuArquivoAlterarUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuArquivoAlterarUsuarioActionPerformed

    private void menuArquivoManutencaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuArquivoManutencaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuArquivoManutencaoActionPerformed

    private void menuMovimentosRelatorioReservaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuMovimentosRelatorioReservaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuMovimentosRelatorioReservaActionPerformed

    private void menuMovimentosRelatorioPagamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuMovimentosRelatorioPagamentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuMovimentosRelatorioPagamentoActionPerformed

    private void menuAjudaSobreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuAjudaSobreActionPerformed
         // Chamando a tela sobre
        Sobre tela = new Sobre ();
        tela.setVisible(true);
    }//GEN-LAST:event_menuAjudaSobreActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // substituindo a data pela data atual do sistema ao inicializar
        java.util.Date data = new java.util.Date ();
        DateFormat mudador = DateFormat.getDateInstance(DateFormat.SHORT);
        lblData.setText(mudador.format(data));
    }//GEN-LAST:event_formWindowActivated

    private void menuArquivoSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuArquivoSairActionPerformed
        // fecha a tela
        int sair = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja sair?","Atenção!!",JOptionPane.YES_NO_OPTION);
        if (sair == JOptionPane.YES_OPTION){  
            System.exit(0);
        }
    }//GEN-LAST:event_menuArquivoSairActionPerformed

    private void menuArquivoUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuArquivoUsuarioActionPerformed
        // TODO add your handling code here:// Chamando a tela sobre
        TelaUsuario tela = new TelaUsuario ();
        tela.setVisible(true);
    }//GEN-LAST:event_menuArquivoUsuarioActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JLabel lblData;
    private javax.swing.JMenu menuAjuda;
    private javax.swing.JMenuItem menuAjudaSobre;
    private javax.swing.JMenu menuArquivo;
    private javax.swing.JMenuItem menuArquivoAlterarSenha;
    private javax.swing.JMenuItem menuArquivoAlterarUsuario;
    private javax.swing.JMenuItem menuArquivoCliente;
    private javax.swing.JMenuItem menuArquivoManutencao;
    private javax.swing.JMenuItem menuArquivoQuadra;
    private javax.swing.JMenuItem menuArquivoReserva;
    private javax.swing.JMenuItem menuArquivoSair;
    private javax.swing.JMenuItem menuArquivoUsuario;
    private javax.swing.JMenu menuMovimentos;
    private javax.swing.JMenuItem menuMovimentosNovaReserva;
    private javax.swing.JMenuItem menuMovimentosRelatorioPagamento;
    private javax.swing.JMenuItem menuMovimentosRelatorioReserva;
    private javax.swing.JMenuItem menuPagamento;
    // End of variables declaration//GEN-END:variables
}
