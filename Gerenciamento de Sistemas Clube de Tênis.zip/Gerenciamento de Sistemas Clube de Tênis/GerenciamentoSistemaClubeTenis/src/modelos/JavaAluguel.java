package modelos;

import telas.TelaLogin;

/**
 *
 * @author cintia
 */
public class JavaAluguel {
    
    
    public static void main (String []args){
        Dados meDados = new Dados ();
        TelaLogin jrLogin = new TelaLogin ();
        jrLogin.setVisible(true);
        
    }
    
}
