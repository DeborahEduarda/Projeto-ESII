package modelos;

import java.sql.Date;

/**
 *
 * @author cintia
 */
public class Usuario {
    
    //atributos
    
    private Date dataCriacao;
    private String nome;
    private String email;
    private String senha;
    private String confirmeSenha;
    private boolean habilitarUsuario;
    private boolean bloquearUsuario;
    private String nivelPermissao;
    
    //construtores

    public Usuario(Date dataCriacao, String nome, String email, String senha, String confirmeSenha, boolean habilitarUsuario, boolean bloquearUsuario, String nivelPermissao) {
        this.dataCriacao = dataCriacao;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.confirmeSenha = confirmeSenha;
        this.habilitarUsuario = habilitarUsuario;
        this.bloquearUsuario = bloquearUsuario;
        this.nivelPermissao = nivelPermissao;
    }
    
    
    //getters e setters

    public Date getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(Date dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getConfirmeSenha() {
        return confirmeSenha;
    }

    public void setConfirmeSenha(String confirmeSenha) {
        this.confirmeSenha = confirmeSenha;
    }

    public boolean isHabilitarUsuario() {
        return habilitarUsuario;
    }

    public void setHabilitarUsuario(boolean habilitarUsuario) {
        this.habilitarUsuario = habilitarUsuario;
    }

    public boolean isBloquearUsuario() {
        return bloquearUsuario;
    }

    public void setBloquearUsuario(boolean bloquearUsuario) {
        this.bloquearUsuario = bloquearUsuario;
    }

    public String getNivelPermissao() {
        return nivelPermissao;
    }

    public void setNivelPermissao(String nivelPermissao) {
        this.nivelPermissao = nivelPermissao;
    }
    
    
    
    
}
