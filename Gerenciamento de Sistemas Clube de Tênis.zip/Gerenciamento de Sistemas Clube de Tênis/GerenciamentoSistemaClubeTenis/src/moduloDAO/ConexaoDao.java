package moduloDAO;

import java.sql.*;
/**
 *
 * @author cintia
 */
public class ConexaoDao {
    //Metodo responsavel para estabelecer conexao com o banco de dados
    public static Connection conector(){
        Connection conexao = null;
        
       
        // a linha abaixo chama o Drive
        String driver = "com.mysql.cj.jdbc.Driver";
        
        // armazenando informacoes referente ao banco
        String url = "jdbc:mysql://localhost:3306/aluguelDeQuadrasDeTenis";
        String user = "root" ;
        String password = "Palmeiras$14" ;
        
        // estabelecendo conexao com o banco
        try {
            Class.forName(driver);
            conexao = DriverManager.getConnection(url,user,password);
            return conexao;
           }catch (Exception e) {
               //a linha abaixo serve para saber onde estou errando
               //System.out.println(e);
               return null;
           }
    }
}