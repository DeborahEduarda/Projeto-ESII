package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import mapeamento.Cliente;
import mapeamento.Telefone;
import utilitario.Conectar;

/**
 *
 * @author cintia
 */
public class TelefoneDAO {
    public void cadastrar (Telefone t){
         Connection con = Conectar.getConectar();
         String sql = "insert into tbtelefone (celular,telefoneResidencial,telefoneComercial,telefoneContato) values (?,?,?,?,)";
         try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setString(1, t.getCelular());
             pstm.setString(2, t.getTelefoneResidencial());
             pstm.setString(3, t.getTelefoneComercial());
             pstm.setString(4, t.getTelefoneContato());
             pstm.executeUpdate();
             pstm.close();
             con.close();
            JOptionPane.showMessageDialog(null,"Cadastrado com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao cadastrar!!");
        }
    }
    public void atualizar (Telefone t){
        Connection con = Conectar.getConectar();
        String sql = "update tbtelefone celular=?,telefoneResidencial=?,telefoneComercial=?,telefoneContato=? where id_Telefone=?";
        try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setString(1, t.getCelular());
             pstm.setString(2, t.getTelefoneResidencial());
             pstm.setString(3, t.getTelefoneComercial());
             pstm.setString(4, t.getTelefoneContato());
             pstm.setInt (5, t.getId_Telefone());
             pstm.executeUpdate();
             pstm.close();
             con.close();
             JOptionPane.showMessageDialog(null,"Atualizado com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao atualizar registro!!");
        }
    }
    public void excluir (Telefone t){
        Connection con = Conectar.getConectar();
        String sql ="delete from tbcliente where id_cliente?";
        int opcao = JOptionPane.showConfirmDialog(null, "Deseja excluir cliente?"+t.getId_Telefone()+"?","Excluir",JOptionPane.YES_NO_OPTION);
        if (opcao == JOptionPane.YES_OPTION){
            try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setInt(1, t.getId_Telefone());
             pstm.executeUpdate();
             pstm.close();
             con.close();
             JOptionPane.showMessageDialog(null,"excluido com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao excluir registro!!");
        }
        }
       
    }
    public List<Telefone> listarTodos(){
        Connection con = Conectar.getConectar();
        List<Telefone> lista = new ArrayList<>();
        String sql = "select *from tbcliente order by nome";
        try (PreparedStatement pstm = con.prepareStatement(sql)){
           ResultSet resultado = pstm.executeQuery();
           while(resultado.next()){
               Telefone t = new Telefone ();
               t.setId_Telefone(resultado.getInt("id_Telefone"));
               t.setCelular(resultado.getString("celular"));
               t.setTelefoneResidencial(resultado.getString("telefoneResidencial"));
               t.setTelefoneComercial(resultado.getString("telefoneComercial"));
               t.setTelefoneContato(resultado.getString("telefoneContato"));
               
               lista.add(t);
               
           }
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar os registros");
        }
        
        return lista;
    }
}
