package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import mapeamento.Cliente;
import mapeamento.Usuario;
import utilitario.Conectar;

/**
 *
 * @author cintia
 */
public class UsuarioDAO {
    public void cadastrar (Usuario u){
         Connection con = Conectar.getConectar();
         String sql = "insert into tbusuario (nome,email,senha,nivelAcesso,estaBloqueado, estaDesabilitado,dataCriacao) values (?,?,?,?,?,?,?)";
         try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setString(1, u.getNome());
             pstm.setString(2, u.getEmail());
             pstm.setString(3, u.getSenha());
             pstm.setString(4, u.getNivelAcesso());
             pstm.setString(5, u.getEstaBloqueado());
             pstm.setString(6, u.getEstaDesabilitado());
             pstm.setString(7, u.getDataCriacao());
             pstm.executeUpdate();
             pstm.close();
             con.close();
            JOptionPane.showMessageDialog(null,"Cadastrado com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao cadastrar!!");
        }
    }
    public void atualizar (Usuario u){
        Connection con = Conectar.getConectar();
        String sql = "update tbusuario nome=?, email=?, senha==?, estaBloqueado=?, estaDesabilitado=?, dataCriacao=? where id_Usuario=?";
        try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setString(1, u.getNome());
             pstm.setString(2, u.getEmail());
             pstm.setString(3, u.getSenha());
             pstm.setString(4, u.getNivelAcesso());
             pstm.setString(5, u.getEstaBloqueado());
             pstm.setString(6, u.getEstaDesabilitado());
             pstm.setString(7, u.getDataCriacao());
             pstm.setInt (8, u.getId_Usuario());
             pstm.executeUpdate();
             pstm.close();
             con.close();
             JOptionPane.showMessageDialog(null,"Atualizado com sucesso!!");
        }catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao atualizar registro!!");
        }
    }
    public void excluir (Usuario u){
        Connection con = Conectar.getConectar();
        String sql ="delete from tbusuario where id_Usuario?";
        int opcao = JOptionPane.showConfirmDialog(null, "Deseja excluir usuário?"+u.getNome()+"?","Excluir",JOptionPane.YES_NO_OPTION);
        if (opcao == JOptionPane.YES_OPTION){
            try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setInt(1, u.getId_Usuario());
             pstm.executeUpdate();
             pstm.close();
             con.close();
             JOptionPane.showMessageDialog(null,"Excluido com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao excluir registro!!");
        }
        }
       
    }
    public List<Usuario> listarTodos(){
        Connection con = Conectar.getConectar();
        List<Usuario> lista = new ArrayList<>();
        String sql = "select *from tbusuario order by nome";
        try (PreparedStatement pstm = con.prepareStatement(sql)){
           ResultSet resultado = pstm.executeQuery();
           while(resultado.next()){
               Usuario u = new Usuario ();
               u.setId_Usuario(resultado.getInt("id_Usuario"));
               u.setNome(resultado.getString("nome"));
               u.setEmail(resultado.getString("email"));
               u.setSenha(resultado.getString("senha"));
               u.setNivelAcesso(resultado.getString("nivelAcesso"));
               u.setEstaBloqueado(resultado.getString("estaBloqueado"));
               u.setEstaBloqueado(resultado.getString("estaDesabilitado"));
                u.setDataCriacao(resultado.getString("dataCriacao"));
               lista.add(u);
               
           }
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar os registros");
        }
        
        return lista;
    }
}
