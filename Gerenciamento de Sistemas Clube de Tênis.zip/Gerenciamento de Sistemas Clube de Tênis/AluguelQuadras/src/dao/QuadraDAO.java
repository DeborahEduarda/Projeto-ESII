package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import mapeamento.Pagamento;
import mapeamento.Quadra;
import utilitario.Conectar;

/**
 *
 * @author cintia
 */
public class QuadraDAO {
    public void cadastrar (Quadra q){
         Connection con = Conectar.getConectar();
         String sql = "insert into tbquadra (id_quadra, nome, tipo, qdCoberta, arquibancada, bancoJogadores, qdBloqueada) values (?,?,?,?,?,?,?,?)";
         try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setInt(1, q.getId_quadra());
             pstm.setString(2, q.getNome());
             pstm.setString(3, q.getTipo());
             pstm.setString(4, q.getQdCoberta());
             pstm.setString(5, q.getArquibancada());
             pstm.setString(6, q.getBancoJogadores());
             pstm.setString(7, q.getQdBloqueada());
             pstm.executeUpdate();
             pstm.close();
             con.close();
            JOptionPane.showMessageDialog(null,"Cadastrado com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao cadastrar!!");
        }
    }
    public void atualizar (Quadra q){
        Connection con = Conectar.getConectar();
        String sql = "update tbquadra nome=?, tipo=?, qdCoberta,=? arquibancada=?, bancoJogadores=?, qdBloqueada=? where id_quadra=?";
        try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setString(1, q.getNome());
             pstm.setString(2, q.getTipo());
             pstm.setString (3, q.getQdCoberta());
             pstm.setString (4, q.getArquibancada());
             pstm.setString (5, q.getBancoJogadores());
             pstm.setString (6, q.getQdBloqueada());
             pstm.setInt (7, q.getId_quadra());
             pstm.executeUpdate();
             pstm.close();
             con.close();
             JOptionPane.showMessageDialog(null,"Atualizado com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao atualizar registro!!");
        }
    }
    public void excluir (Quadra q){
        Connection con = Conectar.getConectar();
        String sql ="delete from tbquadra where id_Pagamento?";
        int opcao = JOptionPane.showConfirmDialog(null, "Deseja excluir?"+q.getId_quadra()+"?","Excluir",JOptionPane.YES_NO_OPTION);
        if (opcao == JOptionPane.YES_OPTION){
            try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setInt(1, q.getId_quadra());
             pstm.executeUpdate();
             pstm.close();
             con.close();
             JOptionPane.showMessageDialog(null,"Excluido com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao excluir registro!!");
        }
        }
       
    }
    public List<Quadra> listarTodos(){
        Connection con = Conectar.getConectar();
        List<Quadra> lista = new ArrayList<>();
        String sql = "select *from tbquadra order by nome";
        try (PreparedStatement pstm = con.prepareStatement(sql)){
           ResultSet resultado = pstm.executeQuery();
           while(resultado.next()){
               Quadra q = new Quadra ();
               q.setId_quadra(resultado.getInt("id_quadra"));
               q.setNome(resultado.getString("nome"));
               q.setTipo(resultado.getString("tipo"));
               q.setQdCoberta(resultado.getString("qdCoberta"));
               q.setArquibancada(resultado.getString("arquibancada"));
               q.setBancoJogadores(resultado.getString("bancoJogadores"));
               q.setQdBloqueada(resultado.getString("qdBloqueada"));
               lista.add(q);
               
           }
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar os registros");
        }
        
        return lista;
    }
}
