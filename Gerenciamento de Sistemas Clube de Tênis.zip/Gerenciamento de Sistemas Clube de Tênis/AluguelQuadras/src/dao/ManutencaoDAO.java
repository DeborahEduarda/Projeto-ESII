package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import mapeamento.Cliente;
import mapeamento.Manutencao;
import utilitario.Conectar;

/**
 *
 * @author cintia
 */
public class ManutencaoDAO {
     public void cadastrar (Manutencao m){
         Connection con = Conectar.getConectar();
         String sql = "insert into tbmanutencao (numeroQuadra,agendarPara,horario) values (?,?,?)";
         try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setString(1, m.getNumeroQuadra());
             pstm.setString(2, m.getAgendarPara());
             pstm.setString(3, m.getHorario());
             pstm.executeUpdate();
             pstm.close();
             con.close();
            JOptionPane.showMessageDialog(null,"Cadastrado com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao cadastrar!!");
        }
    }
    public void atualizar (Manutencao m){
        Connection con = Conectar.getConectar();
        String sql = "update tbmanutencao numeroQuadra=?,agendarPara=?,horario=? where idManutencao=?";
        try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setString(1, m.getNumeroQuadra());
             pstm.setString(2, m.getAgendarPara());
             pstm.setString(3, m.getHorario());
             pstm.setInt (4, m.getIdManutencao());
             pstm.executeUpdate();
             pstm.close();
             con.close();
             JOptionPane.showMessageDialog(null,"Atualizado com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao atualizar registro!!");
        }
    }
    public void excluir (Manutencao m){
        Connection con = Conectar.getConectar();
        String sql ="delete from tbmanutencao where idManutencao?";
        int opcao = JOptionPane.showConfirmDialog(null, "Deseja excluir está manutenção?"+m.getNumeroQuadra()+"?","Excluir",JOptionPane.YES_NO_OPTION);
        if (opcao == JOptionPane.YES_OPTION){
            try (PreparedStatement pstm = con.prepareStatement(sql)){
             pstm.setInt(1, m.getIdManutencao());
             pstm.executeUpdate();
             pstm.close();
             con.close();
             JOptionPane.showMessageDialog(null,"Excluido com sucesso!!");
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(null,"Erro ao excluir registro!!");
        }
        }
       
    }
    public List<Manutencao> listarTodos(){
        Connection con = Conectar.getConectar();
        List<Manutencao> lista = new ArrayList<>();
        String sql = "select *from tbcliente order by nome";
        try (PreparedStatement pstm = con.prepareStatement(sql)){
           ResultSet resultado = pstm.executeQuery();
           while(resultado.next()){
               Manutencao m = new Manutencao ();
               m.setIdManutencao(resultado.getInt("idManutencao"));
               m.setNumeroQuadra(resultado.getString("numeroQuadra"));
               m.setAgendarPara(resultado.getString("agendarPara"));
               m.setHorario(resultado.getString("horario"));
               lista.add(m);
               
           }
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar os registros");
        }
        
        return lista;
    }
}
