package mapeamento;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import java.util.ArrayList;
import Enum.TipoPagamento;
import Enum.TipoQuadra;
import java.time.LocalTime;
import java.time.LocalDate;
/**
 *
 * @author cintia
 */
public class Reserva extends Agendamento{
	
	private String id_reserva;
	private String formaPagamento;

    public Reserva(String id_reserva, String formaPagamento, int id_Agendamento, String quadra, String cliente, String data, String horarioInicio, String horarioFim) {
        super(id_Agendamento, quadra, cliente, data, horarioInicio, horarioFim);
        this.id_reserva = id_reserva;
        this.formaPagamento = formaPagamento;
    }

    public Reserva(String id_reserva, String formaPagamento) {
        this.id_reserva = id_reserva;
        this.formaPagamento = formaPagamento;
    }

    public Reserva() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getId_reserva() {
        return id_reserva;
    }

    public void setId_reserva(String id_reserva) {
        this.id_reserva = id_reserva;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    
    

  

    

    
}
	

