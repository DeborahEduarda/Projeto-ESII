package mapeamento;

import java.util.ArrayList;
import mapeamento.Reserva;
import Enum.TipoPagamento;
import Enum.TipoQuadra;

/**
 *
 * @author cintia
 */
public class Pagamento  {
    
    private int id_Pagamento;
    private String preco;
    private String totalPagar;

 
     
    ArrayList <Pagamento> pagamentos = new ArrayList<Pagamento>();
    
   
    
    public void cadastrar(int id_Pagamento,String preco,String totalPagar) {
                this.setId_Pagamento(id_Pagamento);
		this.setPreco(preco);
		this.setTotalPagar(totalPagar);
		pagamentos.add(this);

 }

    public int getId_Pagamento() {
        return id_Pagamento;
    }

    public void setId_Pagamento(int id_Pagamento) {
        this.id_Pagamento = id_Pagamento;
    }

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }

    public String getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(String totalPagar) {
        this.totalPagar = totalPagar;
    }

     
}

