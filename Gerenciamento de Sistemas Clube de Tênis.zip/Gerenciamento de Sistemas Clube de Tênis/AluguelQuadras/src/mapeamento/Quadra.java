package mapeamento;

import java.time.format.DateTimeFormatter;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import Enum.TipoQuadra;
/**
 *
 * @author cintia
 */
public class Quadra {
        private int id_quadra;
	private String nome;
	private String tipo;
	private String qdCoberta;
	private String arquibancada;
	private String bancoJogadores;
	private String qdBloqueada;

    public int getId_quadra() {
        return id_quadra;
    }

    public void setId_quadra(int id_quadra) {
        this.id_quadra = id_quadra;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getQdCoberta() {
        return qdCoberta;
    }

    public void setQdCoberta(String qdCoberta) {
        this.qdCoberta = qdCoberta;
    }

    public String getArquibancada() {
        return arquibancada;
    }

    public void setArquibancada(String arquibancada) {
        this.arquibancada = arquibancada;
    }

    public String getBancoJogadores() {
        return bancoJogadores;
    }

    public void setBancoJogadores(String bancoJogadores) {
        this.bancoJogadores = bancoJogadores;
    }

    public String getQdBloqueada() {
        return qdBloqueada;
    }

    public void setQdBloqueada(String qdBloqueada) {
        this.qdBloqueada = qdBloqueada;
    }

    

    void setQuadra(TipoQuadra tipo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   
    
}
