package mapeamento;

import java.time.LocalDate;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author cintia
 */
public class Cliente {
    // atributos - características
    private int id_cliente;
    private String nome;
    private String cpf;
    private String genero;
    private String email;
    private String dataNascimento;
    
    ArrayList <Cliente> clientes = new ArrayList<Cliente>();

    public Cliente(String nome, String cpf, String genero, String email, String dataNascimento) {
        
        this.nome = nome;
        this.cpf = cpf;
        this.genero = genero;
        this.email = email;
        this.dataNascimento = dataNascimento;
    }

    public Cliente() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public void cadastrar(String nome,String email, String cpf, String dataNascimento) {
                
		this.setNome(nome);
		this.setEmail(email);
		this.setCpf(cpf);
		this.setDataNascimento(dataNascimento);
		clientes.add(this);
	}

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

   public String getDataNascimento (){
       return dataNascimento;
   }
   public void setDataNascimento(String dataNascimento){
       this.dataNascimento = dataNascimento;
   }
   

    public int getIdManutencao() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   
    
    
}
