package mapeamento;

/**
 *
 * @author cintia
 */
public class Telefone {
    
    private int id_Telefone;
    private String celular;
    private String telefoneResidencial;
    private String telefoneComercial;
    private String telefoneContato;

    public int getId_Telefone() {
        return id_Telefone;
    }

    public void setId_Telefone(int id_Telefone) {
        this.id_Telefone = id_Telefone;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getTelefoneResidencial() {
        return telefoneResidencial;
    }

    public void setTelefoneResidencial(String telefoneResidencial) {
        this.telefoneResidencial = telefoneResidencial;
    }

    public String getTelefoneComercial() {
        return telefoneComercial;
    }

    public void setTelefoneComercial(String telefoneComercial) {
        this.telefoneComercial = telefoneComercial;
    }

    public String getTelefoneContato() {
        return telefoneContato;
    }

    public void setTelefoneContato(String telefoneContato) {
        this.telefoneContato = telefoneContato;
    }

    
    
    
}
