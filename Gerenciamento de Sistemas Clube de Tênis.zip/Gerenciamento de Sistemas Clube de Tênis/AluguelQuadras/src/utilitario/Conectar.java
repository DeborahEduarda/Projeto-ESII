package utilitario;

import java.sql.*;
import javax.swing.JOptionPane;


/**
 *
 * @author cintia - debora - isabela
 **/
public class Conectar { 
    
    
         //Metodo responsavel para estabelecer conexao com o banco de dados
         // armazenando informacoes referente ao banco
    
    private static final String USUARIO = "root";
    private static final String SENHA = "Palmeiras$14" ;
    private static final String URL = "jdbc:mysql://localhost:3306/aluguelquadra";
    
    public static Connection getConectar(){
        Connection con =  null;
        

        // estabelecendo conexao com o banco
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(USUARIO,SENHA,URL);
           
        
           }catch (Exception ex) {
               //a linha abaixo serve para saber onde estou errando
               //System.out.println(e);
               JOptionPane.showMessageDialog(null, "Erro ao conectar com o banco de dados!");
               
           } return con;
           
    }
}
